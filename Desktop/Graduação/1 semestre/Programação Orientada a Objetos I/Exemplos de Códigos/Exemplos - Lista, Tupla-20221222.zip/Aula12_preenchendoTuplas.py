# manipulando Tuplas
from random import randrange, randint


#criando uma tupla vazia
a = ()
b = tuple()
print(a)
print(b)


#preenchendo uma tupla
# randrange permite inserir o passo no "sorteio"
# randrange considera [1,10) - intervalo fechado no início e aberto no final
x = tuple([randrange(1,10,2) for i in range(5)])
print("Tupla x contendo números aleatórios: ",x)

# randint considera [1,10] - intervalo fechado no início e fechado no final
y = (randint(1,10),
     randint(1,10),
     randint(1,10))
print("Tupla y contendo números aleatórios: ", y)

#usando input()
z = (int(input("Digite um valor: ")),
     int(input("Digite um valor: ")),
     int(input("Digite um valor: ")),
     int(input("Digite um valor: ")))
print("Tupla z contendo valores lidos do teclado: ",z)

#extraindo elementos individuais de uma tupla
print("Extraindo elementos de uma tupla (desempacotar)")
tupla = ("Ana","Beto","Carlos")
print(tupla)
nome1, nome2, nome3 = tupla
print("Nome 1:", nome1)
print("Nome 2:", nome2)
print("Nome 3:", nome3)
         
# inserindo elementos individuais de uma tupla em uma lista
print("Extraindo elementos individuais de uma tupla e inserindo em uma lista")
print("Tupla de nomes: ",tupla)
nomes = list(tupla)
print("Lista de nomes:", nomes)


