# convertendo uma lista em tupla
# é possível converter uma lista em tupla em Python usando a função tuple()
# A função tuple() é uma função embutida no Python que pega um objeto iterável
# como entrada e retorna um objeto tupla como saída.

from random import randint

ex_numeros = [1,2,3,4,5]
ex_tupla = tuple(ex_numeros)
print(ex_numeros)
print(ex_tupla)

'''
#atenção ao criar uma lista usando for
numeros = [[randint(1,30) for i in range(10)]]
print(numeros)
print(numeros[0])
#importante: o for criou uma lista com 10 elementos na primeira posição [0] da lista numeros
#conceito de lista composta (uma lista dentro de outra lista)

tupla_numeros = tuple(numeros)
print(tupla_numeros)
#portanto quando eu converto para tupla,
#a tupla_numeros conterá uma lista na sua primeira posição também
print(tupla_numeros[0])

#criando uma lista composta com 2 elementos
numeros2 = [[randint(1,30) for i in range(10)], [randint(1,30) for i in range(10)]]
print(numeros2)
print(numeros2[0])
print(numeros2[1])
'''