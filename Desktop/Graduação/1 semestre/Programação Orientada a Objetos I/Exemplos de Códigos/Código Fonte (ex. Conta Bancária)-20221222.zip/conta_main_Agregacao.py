#main exemplo Aula26 (Agregação)

from cliente import Conta,Cliente

#quando uma conta é criada, precisamos passar um cliente como titular:
cliente = Cliente('João', 'Oliveira', '111.111.111-11')
cliente2 = Cliente('Maria', 'Siqueira','123.456.789-99')

minha_conta = Conta('123-4', cliente, 120.0, 1000.0)
minha_conta2= Conta('136-7',"teste de string - Nome do cliente", 300, 5000)

'''Aqui aconteceu uma atribuição, o valor da variável cliente é copiado
para o atributo titular do objeto ao qual minha_conta se refere.
Em outras palavras, minha_conta tem uma referência ao mesmo Cliente
que cliente se refere, e pode ser acessado através de
minha_conta.titular.
'''
print("Acesso aos dados do cliente pode ser feito via objeto minha_conta ou cliente: ")
print("Através da Classe Conta: ", minha_conta.titular.nome)
print(minha_conta.titular.sobrenome)
print(minha_conta.titular.cpf)

print("Através da Classe Cliente: ",cliente.nome)
print(cliente.get_sobrenome())
print(cliente.get_cpf())

#demais atributos acessa normalmente
print("saldo: ",minha_conta.get_saldo())

#retorna o endereço na memória (onde está a classe) - Não é a informação desejada.
print(minha_conta.titular)
print("usando get: ", minha_conta.get_titular())


print(minha_conta2.titular)
print(minha_conta2.get_titular())

