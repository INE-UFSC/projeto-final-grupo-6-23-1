#main exemplo Composição Aula 26 (Agregação-Composição)

from cliente import Cliente
from conta_historico import Conta,Historico

listaClientes = []
listaContas = []

cliente1 = Cliente('João', 'Oliveira', '11111111111-11')
listaClientes.append(cliente1)

cliente2 = Cliente('José', 'Azevedo', '222222222-22')
listaClientes.append(cliente2)

print("Lista de Clientes:")
for i in range (len(listaClientes)):
    print(listaClientes[i].nome, listaClientes[i].sobrenome, listaClientes[i].cpf)


conta1 = Conta('123-4', cliente1, 200,1000)
conta2 = Conta('123-5', cliente2, 300,1000)
listaContas.append(conta1)
listaContas.append(conta2)
print("\nLista de Contas: ")
for i in range (len(listaContas)):
    print(f"{i+1}º ")
    print("Número da conta: ",listaContas[i].numero)
    print("Saldo: ", listaContas[i].saldo)
    print("Limite: ", listaContas[i].limite)
    print("Histórico (data de abertura): ",listaContas[i].historico.data_abertura)
    print("Extrato: ", listaContas[i].historico.transacoes)
    print("Nome do titular: ",listaContas[i].cliente.nome, listaContas[i].cliente.sobrenome)
    
    
#simulação de movimentação
print("\nDados cliente1:")
print(conta1.cliente.nome)
print(conta1.historico.transacoes)

conta1.deposita(100)
conta1.extrato()
conta1.retira(50)
conta1.transfere(conta2,200)
conta1.extrato()

#motra toda a movimentação que foi inserida na lista
#a cada execução dos métodos anteriores
print("\nImprimindo o histórico: ")
conta1.historico.imprime()
