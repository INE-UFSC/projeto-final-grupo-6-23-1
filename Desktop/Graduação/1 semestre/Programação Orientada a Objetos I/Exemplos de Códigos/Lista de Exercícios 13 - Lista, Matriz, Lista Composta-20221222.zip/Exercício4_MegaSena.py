# Exercício 4 Lista 13
# Sorteio MegaSena  
# Rudolfo

from random import randint

def geraMatriz(linhas):
    resultado = []
    for i in range(linhas):
        resultado.append([])
        for j in range(6):
            resultado[i].append(randint(1,60))
    return resultado


#main

print("\n", "-"*50, "\n", " "*15, "JOGA NA MEGA SENA\n", "-"*50)

jogos = geraMatriz(int(input("Quantos jogos você quer que eu sorteie? ")))

print(f"-=-=-= SORTEANDO {len(jogos)} JOGOS =-=-=-")

for i in range(len(jogos)):
    print(f"Jogo {i+1}: ",jogos[i])

print(f"-=-=-= < BOA SORTE! > =-=-=-\n")
