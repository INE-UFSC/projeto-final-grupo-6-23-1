# Discente : Rudolfo Lange Neto

# URI 1353

from random import randint

def gerarLista(lista, numero): # gera lista de suspeitos com base nos nomes aleatorios
    nomes = []
    for i in range(numero):
        nomes.append(lista[randint(0, len(lista))-1])
    return nomes

def notasSuspeitos(lista):
    resultado = []
    for i in range(len(lista)):
        resultado.append(int(input(f"Informe a nota de suspeição de {lista[i]}: ")))
    return resultado

def definirSuspeito(lista):
    maior = 0
    segundoMaior = maior
    for i in range(1, len(lista)):
        if(lista[i] > lista[maior]):
            segundoMaior = maior
            maior = i

    return segundoMaior


#main

nomes = ['Miguel', 'Arthur', 'Théo', 'Heitor', 'Gael', 'Davi', 'Bernardo', 'Gabriel', 'Ravi', 'Noah', 'Samuel', 'Pedro', 'Benício', 'Benjamin', 'Matheus', 'Isaac', 'Anthony', 'Joaquim', 'Lucas', 'Lorenzo', 'Rafael', 'Nicolas', 'Henrique', 'Murilo', 'João Miguel', 'Lucca', 'Guilherme', 'Henry', 'Bryan', 'Gustavo', 'Felipe', 'Pietro', 'Levi', 'Daniel', 'JoãoPedro', 'Bento', 'Vicente', 'Leonardo', 'Caleb', 'Pedro Henrique', 'Matteo', 'Enzo Gabriel', 'João', 'Antônio', 'Emanuel', 'Enzo', 'Davi Lucca', 'Caio', 'Eduardo', 'João Lucas', 'Thomas']

ans = "s"
print("\n", "-" * 80, "\n", " " * 12, "DETERMINANDO SUSPEITO SHERLOCK HOLMES\n", "-" * 80)

while(ans.lower() == "s"):
    suspeitos = gerarLista(nomes, int(input("Informe quantos estão sendo investigados: ")))
    print("Relação com os nomes dos investigados: ", suspeitos)
    print("De acordo com o método Sherlock, o suspeito principal é : ", suspeitos[definirSuspeito(notasSuspeitos(suspeitos))])
    ans = str(input("Deseja continuar investigando? (S/N) : "))
