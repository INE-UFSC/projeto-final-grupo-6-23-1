#Aula17 Lista Exerc. 13
#Exerc. 5 - Boletim
#Luciana
#usando lista composta [[nome,P1,P2,P3,media], [nome,P1,P2,P3,media],...]

def cadastraAluno():
    aluno = []
    soma=0
    aluno.append(str(input("Informe o nome do aluno: ")))
    for i in range(3):
        aluno.append(float(input(f"Informe a nota {i+1} do aluno: ")))
        soma += aluno[i+1]
    media = soma/3
    aluno.append(media)
    return (aluno[:])

def imprime_boletim(nome):
    flag = False
    for i in range(len(ficha)):
        if nome == ficha[i][0]:
            print("Nome: ", ficha[i][0])
            print("Notas: ",ficha[i][1])
            print("Média: ",ficha[i][2])
            flag = True
    if flag == False:
        print("Aluno não cadastrado.")


#main
ficha = list()

for i in range(int(input('Digite o numero de alunos:'))):
    ficha.append(cadastraAluno())

#imprimir informações de todos os alunos
print(ficha)

while True:
    nome_aluno = input("Digite o nome do aluno para ver as notas: ")
    imprime_boletim(nome_aluno)
    continua = input("Deseja continuar verificando as notas? (S/N)")
    if continua == 'N':
        break

