#Aula17 Lista Exerc. 13
#Exerc. 5 - Boletim
#Luciana
#usando lista composta [[nome,[P1,P2,P3],media], [nome,[P1,P2,P3],media], ...]


def cadastraAluno():
    aluno = list()
    notas = list()
    soma = 0
    
    nome = input('Digite o nome:')
    aluno.append(nome)
    for n in range(3):
        nota = int(input("Digite a nota: "))
        notas.append(nota)
        soma += notas[n]
    media = soma/3
    aluno.append(notas[:])
    aluno.append(media)
        
    return (aluno[:])


#poderia usar 1 único append
#ficha.append([nome,[nota1,nota2, nota3],media])

def imprime_boletim(nome):
    flag = False
    for i in range(len(ficha)):
        if nome == ficha[i][0]:
            print("Nome: ", ficha[i][0])
            print("Notas: ",ficha[i][1])
            print("Média: ",ficha[i][2])
            flag = True
    if flag == False:
        print("Aluno não cadastrado.")

#main
ficha = list()

for i in range(int(input('Digite o numero de alunos:'))):
    ficha.append(cadastraAluno())

#imprimir informações de todos os alunos
print(ficha)

while True:
    nome_aluno = input("Digite o nome do aluno para ver as notas: ")
    imprime_boletim(nome_aluno)
    continua = input("Deseja continuar verificando as notas? (S/N)")
    if continua == 'N':
        break
