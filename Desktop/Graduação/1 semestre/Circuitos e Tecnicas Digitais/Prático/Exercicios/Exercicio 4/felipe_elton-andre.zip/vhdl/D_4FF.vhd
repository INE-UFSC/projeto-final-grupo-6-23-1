library IEEE;
use IEEE.Std_Logic_1164.all;

entity D_4FF is 
port (
    CLK, RST, EN: in std_logic;
    D: in std_logic_vector(3 downto 0);
    Q: out std_logic_vector(3 downto 0)
);
end D_4FF;

architecture arc_d_4ff of D_4FF is
begin 

    P1: process (CLK, RST, EN, D)
    begin
        if RST = '1' then
            Q <= "0000";
        elsif CLK'event and CLK = '0' then
            if EN = '1' then
                Q <= D;
            end if;
        end if;
    end process;

end arc_d_4ff;