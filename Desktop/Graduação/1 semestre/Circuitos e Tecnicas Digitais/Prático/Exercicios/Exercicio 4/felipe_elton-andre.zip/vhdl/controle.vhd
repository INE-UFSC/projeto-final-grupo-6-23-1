library ieee;
use ieee.std_logic_1164.all;

entity controle is 
port (
    clock, reset: in std_logic;
    RSET: out std_logic;
    S: out std_logic_vector(1 downto 0));
end controle;

architecture bhv of controle is
	type STATES is (E0,E1,E2,E3,E4,E5);
	signal EA, PE: STATES;
begin
	-- OBS: especificar o valor de saída do sinal de comando RESET (RSET) em todos os estados!!!!!
	-- inserir seu código abaixo

    P1: process(clock, reset)
    begin
        if reset = '0' then
            EA <= E0;
        elsif clock'event and clock = '1' then
            EA <= PE;
        end if;
    end process;
    
    P2: process(EA)
    begin
        case EA is
        when E0 => PE <= E1;
            RSET <= '1';
            S <= "00";
        when E1 => PE <= E2;
            RSET <= '0';
            S <= "01";
        when E2 => PE <= E3;
            RSET <= '0';
            S <= "11";
        when E3 => PE <= E4;
            RSET <= '0';
            S <= "11";
        when E4 => PE <= E5;
            RSET <= '0';
            S <= "01";
        when E5 => PE <= E0;
            RSET <= '0';
            S <= "10";
        end case;
    end process;

end bhv;