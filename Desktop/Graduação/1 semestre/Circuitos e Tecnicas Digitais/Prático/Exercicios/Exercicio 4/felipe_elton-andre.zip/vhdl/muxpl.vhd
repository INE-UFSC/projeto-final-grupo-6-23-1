library IEEE;
use IEEE.Std_Logic_1164.all;

entity muxpl is
port (
    S0,S1,S2,S3: in std_logic_vector(3 downto 0);
    SEL: in std_logic_vector(1 downto 0);
    F: out std_logic_vector(3 downto 0)
);
end muxpl;

architecture arc_muxpl of muxpl is
begin 
    with SEL select
    F <=
        S0 when "00",
        S1 when "01",
        S2 when "10",
        S3 when others;
end arc_muxpl;