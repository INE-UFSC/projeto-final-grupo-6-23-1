library IEEE;
use IEEE.Std_Logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity circuito1 is
port (
    I,Q: in std_logic_vector(3 downto 0);
    S0,S1,S2,S3: out std_logic_vector(3 downto 0));
end circuito1;

architecture circ1 of circuito1 is
begin 

    S0 <= I;
    S1 <= I + Q;
    S2 <= '0' & Q(3 downto 1);
    S3 <= Q(2 downto 0) & '0';

end circ1;