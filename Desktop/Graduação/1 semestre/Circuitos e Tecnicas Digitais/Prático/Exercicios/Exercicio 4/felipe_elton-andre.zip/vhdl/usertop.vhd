library IEEE;
use IEEE.Std_Logic_1164.all;

entity usertop is
port(
    CLK_1Hz:        in std_logic;
	KEY:		in std_logic_vector(1 downto 0);
	SW:		in std_logic_vector(5 downto 0);
	LEDR:		out std_logic_vector(3 downto 0)
);
end usertop;

architecture mult3arch of usertop is
    
    component controle is 
    port (
    	clock, reset: in std_logic;
    	RSET: out std_logic;
    	S: out std_logic_vector(1 downto 0)
    );
    end component;
    
    component datapath is
    port(
    	CLK:		in std_logic;
    	ENABLE:		in std_logic; 
    	RESET:		in std_logic;
    	SWT:		in std_logic_vector(3 downto 0);
    	S:		in std_logic_vector(1 downto 0);
    	Q:		out std_logic_vector(3 downto 0)
    );
    end component;

    signal SEL: std_logic_vector(1 downto 0);
    signal RST: std_logic;

begin

    CONT: controle port map (
        clock => CLK_1Hz,
        reset => KEY(0),
        RSET => RST,
        S => SEL
    );
    
    DATA: datapath port map (
        CLK => CLK_1Hz,
        ENABLE => SW(5),
        RESET => RST,
        SWT => SW(3 downto 0),
        S => SEL,
        Q => LEDR(3 downto 0)
    );

end mult3arch;