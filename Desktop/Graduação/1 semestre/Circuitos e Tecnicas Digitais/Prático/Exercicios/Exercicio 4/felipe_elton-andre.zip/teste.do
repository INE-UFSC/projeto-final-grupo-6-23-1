# no script abaixo, substituir (caso necessário) o texto "usertop" pelo nome do arquivo topo da hierarquia de seu projeto
# substituir  em "SW(3 downto 0) 10#4" o valor 4 pelo valor inicial de I

restart -f
force sim:/usertop/CLK_1Hz 1 0,0 5 -r 10
force sim:/usertop/KEY(0) 0 0, 1 10
force sim:/usertop/SW(5) 1 0
force sim:/usertop/SW(3 downto 0) 10#2 0 

run 80
