library IEEE;
use IEEE.Std_Logic_1164.all;

entity datapath is
port(
	CLK:		in std_logic;
	ENABLE:		in std_logic; 
	RESET:		in std_logic;
	SWT:		in std_logic_vector(3 downto 0);
	S:		in std_logic_vector(1 downto 0);
	Q:		out std_logic_vector(3 downto 0)
);
end datapath;

architecture mult3arch of datapath is

    component circuito1 is
    port (
        I,Q: in std_logic_vector(3 downto 0);
        S0,S1,S2,S3: out std_logic_vector(3 downto 0)
    );
    end component;
    
    component muxpl is
    port (
        S0,S1,S2,S3: in std_logic_vector(3 downto 0);
        SEL: in std_logic_vector(1 downto 0);
        F: out std_logic_vector(3 downto 0)
    );
    end component;
    
    component D_4FF is 
    port (
        CLK, RST, EN: in std_logic;
        D: in std_logic_vector(3 downto 0);
        Q: out std_logic_vector(3 downto 0)
    );
    end component;
    
    signal S0,S1,S2,S3,F,SAIDA: std_logic_vector(3 downto 0);

begin
    
    CIRC: circuito1 port map (
        I => SWT,
        Q => SAIDA,
        S0 => S0, S1 => S1, S2 => S2, S3 => S3
    );
    
    MUX: muxpl port map (
        S0 => S0, S1 => S1, S2 => S2, S3 => S3,
        SEL => S,
        F => F
    );
    
    DFF: D_4FF port map (
        CLK => CLK,
        RST => RESET,
        EN => ENABLE,
        D => F,
        Q => SAIDA
    );
    
    Q <= SAIDA;

end mult3arch;