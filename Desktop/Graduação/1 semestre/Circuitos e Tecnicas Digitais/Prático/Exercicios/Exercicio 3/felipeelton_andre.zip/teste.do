restart -f

force -freeze sim:/usertop/CLK_1Hz 1 0, 0 10 -repeat 20 -cancel 260
force -freeze sim:/usertop/KEY(0) 0 0
run 10

force -freeze sim:/usertop/KEY(0) 1 0
run 210

force -freeze sim:/usertop/KEY(0) 0 0
run 40
