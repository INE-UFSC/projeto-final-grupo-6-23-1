library IEEE;
use IEEE.Std_Logic_1164.all;

entity registrador is
port (
    CLK, RST: in std_logic;
    D:        in std_logic_vector(3 downto 0);
    Q:        out std_logic_vector(3 downto 0)
);
end registrador;

architecture reg of registrador is
begin
    process (CLK, RST, D)
    begin
        if RST = '0' then
            Q <= "0000";
        elsif rising_edge(CLK) then
            Q <= D;
        end if;
    end process;
end reg;

