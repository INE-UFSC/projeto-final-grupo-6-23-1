library IEEE;
use IEEE.Std_Logic_1164.all;

entity usertop is
port(
	CLK_1Hz: 	in std_logic;
	KEY:		in std_logic_vector(1 downto 0);  -- utilizado apenas KEY(0)
	LEDR:		out std_logic_vector(3 downto 0);
	HEX0:       out std_logic_vector(6 downto 0)
);
end usertop;

architecture arch_user of usertop is
signal S, N: std_logic_vector(3 downto 0);


component registrador is 
port (
        CLK, RST: in std_logic;
        D: in std_logic_vector(3 downto 0);
        Q: out std_logic_vector(3 downto 0)
);
end component;

component decoder is
port (
        A: in std_logic_vector(3 downto 0);
        S: out std_logic_vector(6 downto 0)
);
end component;

-- caso queira, pode criar componente que implemente a "Lógica"

begin
    REG: registrador port map (
        CLK => CLK_1HZ,
        RST => KEY(0),
        D => N,
        Q => S
    );
    
    N(3) <= (not S(3) and not S(2)) or (not S(3) and S(1)) or (S(3) and not S(1));
    N(2) <= (not S(3) and S(0)) or (S(2) and not S(0));
    N(1) <= not S(1);
    N(0) <= (S(2) and not S(1)) or (not S(2) and S(1));
    
    LEDR <= S;
    
    DEC: decoder port map (
        A => S,
        S => HEX0
    );
end arch_user;