restart -f
force -freeze sim:/exercicio1/SW(3) 0 0, 1 80 -cancel 160
force -freeze sim:/exercicio1/SW(2) 0 0, 1 40 -repeat 80 -cancel 160
force -freeze sim:/exercicio1/SW(1) 0 0, 1 20 -repeat 40 -cancel 160
force -freeze sim:/exercicio1/SW(0) 0 0, 1 10 -repeat 20 -cancel 160
run 130
