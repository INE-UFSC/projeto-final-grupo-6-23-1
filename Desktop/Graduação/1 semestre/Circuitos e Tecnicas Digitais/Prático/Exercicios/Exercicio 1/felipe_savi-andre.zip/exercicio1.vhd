library IEEE;
use IEEE.Std_Logic_1164.all;

entity exercicio1 is
port (
    SW: in std_logic_vector(3 downto 0);
    LEDR: out std_logic_vector(3 downto 0)
);
end exercicio1;

architecture arc_exercicio1 of exercicio1 is
begin
    LEDR(0) <= (SW(3) and SW(2)) or (SW(3) and SW(1) and SW(0));
    LEDR(1) <= (not SW(3) and not SW(2)) or (not SW(3) and not SW(1));
    LEDR(2) <= not SW(0);
    LEDR(3) <= (SW(3) and SW(1) and not SW(0)) or (not SW(3) and SW(2) and not SW(1) and SW(0));
end arc_exercicio1;

