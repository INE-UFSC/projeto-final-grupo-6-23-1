library IEEE;
use IEEE.Std_Logic_1164.all;

entity decod is
port (
    G: in std_logic_vector(1 downto 0);
    F: out std_logic_vector(6 downto 0)
);
end decod;

architecture circuito of decod is
begin
    with G select
        F <= 
            "1000000" when "00",
            "0000010" when "01",
            "0000000" when "10",
            "0100100" when others;
end circuito;