library IEEE;
use IEEE.Std_Logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity Circuito1 is
port (
    A: in std_logic_vector(3 downto 0);
    F1,F2,F3,F4: out std_logic_vector(3 downto 0)
);
end Circuito1;

architecture Circ1 of Circuito1 is
begin
    F1 <= A + "0000";
    F2 <= A + "0110";
    F3 <= A + "1000";
    F4 <= A + "1110";
end Circ1;