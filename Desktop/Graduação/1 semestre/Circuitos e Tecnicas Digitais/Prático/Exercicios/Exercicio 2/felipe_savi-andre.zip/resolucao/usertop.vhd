library IEEE;
use IEEE.Std_Logic_1164.all;

entity usertop is
port(
    -- A: 3-0
    -- C: 6-5
	SW:		in std_logic_vector(6 downto 0);
	HEX0,HEX1,HEX2,HEX3,HEX4,HEX5,HEX6: out std_logic_vector(6 downto 0)
);
end usertop;

architecture circuito_exe2 of usertop is
    component Circuito1 is
    port (
        A: in std_logic_vector(3 downto 0);
        F1,F2,F3,F4: out std_logic_vector(3 downto 0)
    );
    end component;
    
    component mux4_1 is
    port (
        F1,F2,F3,F4: in std_logic_vector(3 downto 0);
        sel: in std_logic_vector(1 downto 0);
        F: out std_logic_vector(3 downto 0)
    );
    end component;
    
    component mux2_1 is
    port (
        F1: in std_logic_vector(6 downto 0);
        F2: in std_logic_vector(6 downto 0);
        sel: in std_logic;
        F: out std_logic_vector(6 downto 0)
    );
    end component;
    
    component decod_C2 is
    port (
        G: in std_logic_vector(3 downto 0);
        F: out std_logic_vector(6 downto 0)
    );
    end component;
    
    component  decod is
    port (
        G: in std_logic_vector(1 downto 0);
        F: out std_logic_vector(6 downto 0)
    );
    end component;
    
    signal F, F1, F2, F3, F4: std_logic_vector(3 downto 0); 

begin
    CIRC: Circuito1 port map (
        A => SW(3 downto 0),
        F1 => F1,
        F2 => F2,
        F3 => F3,
        F4 => F4
    );
    
    MUX4_1_A: mux4_1 port map (
        F1 => F1,
        F2 => F2,
        F3 => F3,
        F4 => F4,
        sel => SW(6 downto 5),
        F => F
    );
    
    MUX2_1_A: mux2_1 port map (
        F1 => "1111111",
        F2 => "0111111",
        sel => SW(3),
        F => HEX6
    );
    
    DECOD_C2_A: decod_C2 port map (
        G => SW(3 downto 0),
        F => HEX5
    );
    
    MUX2_1_B: mux2_1 port map (
        F1 => "0001111",
        F2 => "0111111",
        sel => SW(6),
        F => HEX4
    );
    
    DECOD_A: decod port map (
        G => SW(6 downto 5),
        F => HEX3
    );
    
    HEX2 <= "0110111";
    
    MUX2_1_C: mux2_1 port map (
        F1 => "1111111",
        F2 => "0111111",
        sel => F(3),
        F => HEX1
    );

    DECOD_C2_B: decod_C2 port map (
        G => F,
        F => HEX0
    );

end circuito_exe2;