-- OBS: Basta criar o componente uma vez e usa-lo mais de uma vez no usertop com diferentes entradas
library IEEE;
use IEEE.Std_Logic_1164.all;

entity mux2_1 is
port (
    F1: in std_logic_vector(6 downto 0);
    F2: in std_logic_vector(6 downto 0);
    sel: in std_logic;
    F: out std_logic_vector(6 downto 0)
);
end mux2_1 ;

architecture circuito of mux2_1  is
begin
    with sel select
        F <=
            F1 when '0',
            F2 when others;
end circuito;