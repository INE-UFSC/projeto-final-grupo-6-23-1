restart -f
force -freeze sim:/usertop/SW(4) 0 0
force -freeze sim:/usertop/SW(3 downto 0) 0000 0
force -freeze sim:/usertop/SW(3 downto 0) 0001 40
force -freeze sim:/usertop/SW(3 downto 0) 0111 80
force -freeze sim:/usertop/SW(3 downto 0) 1000 120

force -freeze sim:/usertop/SW(6) 0 0, 1 20 -repeat 40 -cancel 160
force -freeze sim:/usertop/SW(5) 0 0, 1 10 -repeat 20 -cancel 160
run 160
