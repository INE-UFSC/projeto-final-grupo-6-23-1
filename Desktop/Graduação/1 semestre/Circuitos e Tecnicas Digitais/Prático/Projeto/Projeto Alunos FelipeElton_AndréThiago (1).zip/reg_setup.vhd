library ieee;
use ieee.std_logic_1164.all;

entity reg_setup is 
port(
    clk, r, e: in std_logic;
	sw: in std_logic_vector(7 downto 0);
	setup: out std_logic_vector(7 downto 0)
 );
end entity;

architecture arc of reg_setup is
begin
    process(clk, r, e, sw)
    begin
        if r = '1' then
            setup <= "00000000";
        elsif rising_edge(clk) and e = '1' then
            setup <= sw;
        end if;
    end process;
end arc;
