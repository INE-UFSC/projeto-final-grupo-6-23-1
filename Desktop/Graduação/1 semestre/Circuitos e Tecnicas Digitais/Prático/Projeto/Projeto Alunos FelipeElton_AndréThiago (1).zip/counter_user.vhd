library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity counter_user is
port(
    clk: in std_logic;
    r: in std_logic;
    e : in std_logic;
	data: in std_logic_vector(3 downto 0);		
    tc: out std_logic 								
);
end entity;

architecture arc of counter_user is
    signal sig_sequser: std_logic_vector(3 downto 0);
begin
    process(data, clk, r, e)
    begin
        if r = '1' then
            sig_sequser <= "0000";
            tc <= '0';
        elsif rising_edge(clk) and e = '1' then
            if sig_sequser = data then
                -- todo
                -- sig_sequser <= "0000"?
                tc <= '1';
            else
                sig_sequser <= sig_sequser + 1; 
                tc <= '0';
            end if;
        end if;
    end process;
end arc;

