library ieee;
use ieee.std_logic_1164.all;

entity reg_fpga is 
port(
    clk, r, e: in std_logic;
	data: in std_logic_vector(63 downto 0);
	q: out std_logic_vector(63 downto 0)
 );
end entity;

architecture arc of reg_fpga is
begin
    process(clk, r, e, data)
    begin
        if r = '1' then
            q <= "0000000000000000000000000000000000000000000000000000000000000000";
        elsif rising_edge(clk) and e = '1' then
            q <= data;
        end if;
    end process;
end arc;
