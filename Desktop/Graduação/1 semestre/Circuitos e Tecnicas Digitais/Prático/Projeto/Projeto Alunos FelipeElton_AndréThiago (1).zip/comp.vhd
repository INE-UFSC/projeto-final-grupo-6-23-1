library ieee;
use ieee.std_logic_1164.all;

entity comp is 
port(
	seq_fpga, seq_usuario: in std_logic_vector(63 downto 0);
	eq: out std_logic
 );
end entity;

architecture arc of comp is
begin
    eq <= '1' when seq_fpga = seq_usuario else '0';
end arc;

