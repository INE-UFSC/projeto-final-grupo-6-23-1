-- button press synchronizer para keys que são ativas baixas (ou seja, quando pressionadas vao para nivel baixo)

library ieee;
use ieee.std_logic_1164.all; 

entity buttonsync is
	port
	(
		key0, key1, key2, key3, clk: in std_logic;
		btn0, btn1, btn2, btn3: out std_logic
	);
end buttonsync;


architecture buttonsyncimpl of buttonsync is
type states is (esperaapertar, saidaativa, esperasoltar);
signal btn0state, btn1state, btn2state, btn3state : states := esperaapertar;
signal btn0next, btn1next, btn2next, btn3next : states := esperaapertar;
begin

	process (clk) 
	begin
		if clk'event and clk = '1' then -- resposta na transicao positiva do clock
			btn0state <= btn0next;			
			btn1state <= btn1next;
			btn2state <= btn2next;
			btn3state <= btn3next;
		end if;
	end process;
	
	process (key0,btn0state)
	begin
		case btn0state is
			when esperaapertar =>
				if key0 = '0' then btn0next <= saidaativa; else btn0next <= esperaapertar; end if;
				btn0 <= '1';
			when saidaativa =>
				if key0 = '0' then btn0next <= esperasoltar; else btn0next <= esperaapertar; end if;	
				btn0 <= '0';
			when esperasoltar =>
				if key0 = '0' then btn0next <= esperasoltar;	else btn0next <= esperaapertar; end if;	
				btn0 <= '1';
		end case;		
	end process;
	
	process (key1,btn1state)
	begin
		case btn1state is
			when esperaapertar =>
				if key1 = '0' then btn1next <= saidaativa; else btn1next <= esperaapertar; end if;
				btn1 <= '1';
			when saidaativa =>
				if key1 = '0' then btn1next <= esperasoltar; else btn1next <= esperaapertar; end if;	
				btn1 <= '0';
			when esperasoltar =>
				if key1 = '0' then btn1next <= esperasoltar;	else btn1next <= esperaapertar; end if;	
				btn1 <= '1';
		end case;		
	end process;
	
	process (key2,btn2state)
	begin
		case btn2state is
			when esperaapertar =>
				if key2 = '0' then btn2next <= saidaativa; else btn2next <= esperaapertar; end if;
				btn2 <= '1';
			when saidaativa =>
				if key2 = '0' then btn2next <= esperasoltar; else btn2next <= esperaapertar; end if;	
				btn2 <= '0';
			when esperasoltar =>
				if key2 = '0' then btn2next <= esperasoltar;	else btn2next <= esperaapertar; end if;	
				btn2 <= '1';
		end case;		
	end process;
	
	process (key3,btn3state)
	begin
		case btn3state is
			when esperaapertar =>
				if key3 = '0' then btn3next <= saidaativa; else btn3next <= esperaapertar; end if;
				btn3 <= '1';
			when saidaativa =>
				if key3 = '0' then btn3next <= esperasoltar; else btn3next <= esperaapertar; end if;	
				btn3 <= '0';
			when esperasoltar =>
				if key3 = '0' then btn3next <= esperasoltar;	else btn3next <= esperaapertar; end if;	
				btn3 <= '1';
		end case;		
	end process;

end buttonsyncimpl;
