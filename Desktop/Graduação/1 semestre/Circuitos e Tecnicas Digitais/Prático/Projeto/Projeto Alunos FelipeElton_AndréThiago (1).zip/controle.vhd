library ieee;
use ieee.std_logic_1164.all;

entity controle is
port(
	-- entradas de controle
	clock: in std_logic;
	enter: in std_logic;
	reset: in std_logic;
	-- entradas de status
	end_fpga, end_user, end_time, win, match: in std_logic;
	-- saídas de comandos
	r1, r2, e1, e2, e3, e4: out std_logic;
	sel: out std_logic
);
end controle;

architecture arc of controle is
	type states is (init, setup, play_fpga, play_user, check, next_round, result);
	signal ea, pe: states;
begin
    p1: process(reset, clock, pe)
    begin
        if reset = '1' then
            ea <= init;
        elsif rising_edge(clock) then
            ea <= pe;
        end if;
    end process;
    
    p2: process(ea, enter, end_fpga, end_time, end_user, match, win)
    begin
        case ea is
        when init =>
            pe <= setup;
            
            r1 <= '1';
            r2 <= '1';
            e1 <= '0';
            e2 <= '0';
            e3 <= '0';
            e4 <= '0';
            sel <= '0';
        when setup =>
            if enter = '1' then
                pe <= play_fpga;
            else
                pe <= ea;
            end if;
            
            r1 <= '0';
            r2 <= '0';
            e1 <= '1';
            e2 <= '0';
            e3 <= '0';
            e4 <= '0';
            sel <= '0';
        when play_fpga =>
            if end_fpga = '1' then
                pe <= play_user;
            else
                pe <= ea;
            end if;
            
            r1 <= '0';
            r2 <= '0';
            e1 <= '0';
            e2 <= '0';
            e3 <= '1';
            e4 <= '0';
            sel <= '0';
        when play_user =>
            if end_time = '1' then
                pe <= result;
            elsif end_user = '1' then
                pe <= check;
            else
                pe <= ea;
            end if;
            
            r1 <= '0';
            r2 <= '0';
            e1 <= '0';
            e2 <= '1';
            e3 <= '0';
            e4 <= '0';
            sel <= '0';
        when check =>
            if match = '1' then
                pe <= next_round;
            else
                pe <= result;
            end if;
            
            r1 <= '0';
            r2 <= '0';
            e1 <= '0';
            e2 <= '0';
            e3 <= '0';
            e4 <= '1';
            sel <= '0';
        when next_round =>
            if win = '0' then
                pe <= play_fpga;
            else
                pe <= result;
            end if;
            
            r1 <= '0';
            r2 <= '1';
            e1 <= '0';
            e2 <= '0';
            e3 <= '0';
            e4 <= '0';
            sel <= '0';
        when result =>
            pe <= ea;
        
            r1 <= '0';
            r2 <= '0';
            e1 <= '0';
            e2 <= '0';
            e3 <= '0';
            e4 <= '0';
            sel <= '1';
        end case;
    end process;
end arc;
