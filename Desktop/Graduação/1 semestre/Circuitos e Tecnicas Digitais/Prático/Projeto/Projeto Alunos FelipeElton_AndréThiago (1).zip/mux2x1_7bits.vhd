library ieee;
use ieee.std_logic_1164.all;

entity mux2x1_7bits is
port(
	sel: in std_logic;
    ent0, ent1: in std_logic_vector(6 downto 0);
    output: out std_logic_vector(6 downto 0)
);
end entity;

architecture arc of mux2x1_7bits is

begin
    with sel select
        output <=
            ent0 when '0',
            ent1 when others;
end arc;
