library ieee;
use ieee.std_logic_1164.all; 
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity datapath is
port(
	-- entradas de dados
	clock: in std_logic;
	key: in std_logic_vector(3 downto 0);
	switch: in std_logic_vector(7 downto 0);

	-- entradas de controle
	r1, r2, e1, e2, e3, e4: in std_logic;
	sel: in std_logic;

	-- saídas de dados
	hex0, hex1, hex2, hex3, hex4, hex5: out std_logic_vector(6 downto 0);
	leds: out std_logic_vector(3 downto 0);
	ledg: out std_logic_vector(3 downto 0);
	
	-- saídas de status
	end_fpga, end_user, end_time, win, match: out std_logic
);
end entity;

architecture arc of datapath is
---------------------------signals-----------------------------------------------------------

	signal btn0: std_logic;
	signal btn1: std_logic;
	signal btn2: std_logic;
	signal btn3: std_logic;
	signal nbtn, notkeys: std_logic_vector(3 downto 0);

	signal e_counter_user: std_logic;
	signal data_reg_fpga: std_logic_vector(63 downto 0);
	signal data_reg_user: std_logic_vector(63 downto 0);
	signal c1aux, c2aux: std_logic;

	signal setup: std_logic_vector(7 downto 0);

	signal c05hz, c07hz, c09hz, c1hz, c11hz, c12hz, c13hz, c14hz, c15hz, c16hz, c17hz, c18hz, c19hz: std_logic;
	signal c2hz, c21hz, c22hz, c23hz, c24hz, c25hz, c26hz, c27hz, c28hz, c29hz, c3hz, c31hz, c32hz: std_logic;
	signal c33hz, c34hz, c35hz, c36hz, c38hz, c4hz, c42hz, c44hz, c46hz, c48hz, c5hz: std_logic;
	signal c52hz, c54hz, c56hz, c58hz, c6hz: std_logic;

	signal win_internal: std_logic;
	signal round: std_logic_vector(3 downto 0);

	signal tempo: std_logic_vector(3 downto 0);

	signal seqfpga: std_logic_vector(3 downto 0);

	signal seq_fpga: std_logic_vector(3 downto 0);

	signal end_user_internal: std_logic;

	signal out_fpga: std_logic_vector(63 downto 0);

	signal out_user: std_logic_vector(63 downto 0);	

	signal is_equal: std_logic;

	signal points: std_logic_vector(7 downto 0);

	signal g_dec7seghex4: std_logic_vector(3 downto 0);

	signal points_bcd: std_logic_vector(7 downto 0);

	signal dec7seghex4: std_logic_vector(6 downto 0);

	signal dec7seghex2: std_logic_vector(6 downto 0);

	signal dec7seghex1: std_logic_vector(6 downto 0);

	signal dec7seghex00: std_logic_vector(6 downto 0);

	signal dec7seghex01: std_logic_vector(6 downto 0);
	

	signal output_mux0hex5: std_logic_vector(6 downto 0);

	signal saida0mux16_1, saida1mux16_1, saida2mux16_1, saida3mux16_1: std_logic;
	
	signal output_mux0hex2: std_logic_vector(6 downto 0);
	
	signal output_mux0hex3: std_logic_vector(6 downto 0);

	signal output_mux0hex4: std_logic_vector(6 downto 0);

	signal mux4x1_4bits00: std_logic_vector(3 downto 0);
	signal mux4x1_4bits01: std_logic_vector(3 downto 0);
	signal mux4x1_4bits10: std_logic_vector(3 downto 0);
	signal mux4x1_4bits11: std_logic_vector(3 downto 0);

	signal clkhz: std_logic;	
	
---------------------------components-----------------------------------------------------------

--------------------------mux4x1_4bits----------------------------------
component mux4x1_4bits is
port(
	sel: in std_logic_vector(1 downto 0);
    ent0, ent1, ent2, ent3: in std_logic_vector(3 downto 0);
    output: out std_logic_vector(3 downto 0)
);
end component;
-------------------------mux2x1_7bits-------------------------------------
component mux2x1_7bits is
port(
	sel: in std_logic;
    ent0, ent1: in std_logic_vector(6 downto 0);
    output: out std_logic_vector(6 downto 0)
);
end component;
----------------------------mux4x1_1bit-----------------------------------
component mux4x1 is
port(level: in std_logic_vector(1 downto 0);
    cl1, cl2, cl3, cl4: in std_logic;
    clkhz: out std_logic
);
end component;
-------------------------mux16x1_clock------------------------------------
component mux16x1 is
port(sel: in std_logic_vector(3 downto 0);
    f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16: in std_logic;
    clkhz: out std_logic
);
end component;
---------------------------dec7seg----------------------------------------
component dec7seg is
port(
    g: in std_logic_vector(3 downto 0);
	o: out std_logic_vector(6 downto 0)
);
end component;
---------------------------reg_setup--------------------------------------
component reg_setup is 
port(clk, r, e: in std_logic;
	sw: in std_logic_vector(7 downto 0);
	setup: out std_logic_vector(7 downto 0)
 );
end component;
---------------------------reg_fpga---------------------------------------
component reg_fpga is 
port(clk, r, e: in std_logic;
	data: in std_logic_vector(63 downto 0);
	q: out std_logic_vector(63 downto 0)
 );
end component;
---------------------------reg_user---------------------------------------
component reg_user is 
port(clk, r, e: in std_logic;
	data: in std_logic_vector(63 downto 0);
	q: out std_logic_vector(63 downto 0)
 );
end component;
-----------------------------decseq00-------------------------------------
component decseq00 is
port(
	address: in std_logic_vector(3 downto 0);
	output: out std_logic_vector(3 downto 0)
);
end component;
-----------------------------decseq01-------------------------------------
component decseq01 is
port(
	address: in std_logic_vector(3 downto 0);
	output: out std_logic_vector(3 downto 0)
);
end component;
-----------------------------decseq10-------------------------------------
component decseq10 is
port(
	address: in std_logic_vector(3 downto 0);
	output: out std_logic_vector(3 downto 0)
);
end component;
-----------------------------decseq11-------------------------------------
component decseq11 is
port(
	address: in std_logic_vector(3 downto 0);
	output: out std_logic_vector(3 downto 0)
);
end component;
-------------------------counter_time-------------------------------------
component counter_time is
port(clkt: in std_logic;
    r: in std_logic;
    e: in std_logic;
    tempo: out std_logic_vector(3 downto 0);
    end_time: out std_logic
);
end component;
------------------------counter_round-------------------------------------
component counter_round is
port(
	 data: in std_logic_vector(3 downto 0);
	 clk: in std_logic;
    r: in std_logic;
    e: in std_logic;
    tc : out std_logic;	
    round: out std_logic_vector(3 downto 0)
);
end component;
-------------------------counter_fpga-------------------------------------
component counter_fpga is
port(clk: in std_logic;
    r: in std_logic;
    e : in std_logic;
	 data: in std_logic_vector(3 downto 0);
	 tc: out std_logic;	
    seqfpga: out std_logic_vector(3 downto 0)
);
end component;
-------------------------counter_user-------------------------------------
component counter_user is
port(clk: in std_logic;
    r: in std_logic;
    e : in std_logic;
	 data: in std_logic_vector(3 downto 0);		
	 tc: out std_logic 								
);
end component;
----------------------div_freq_de2----------------------------------------
component div_freq_de2 is
port(reset: in std_logic;
	clock: in std_logic;
	c05hz, c07hz, c09hz, c1hz, c11hz, c12hz, c13hz, c14hz, c15hz, c16hz, c17hz, c18hz, c19hz: out std_logic;
	c2hz, c21hz, c22hz, c23hz, c24hz, c25hz, c26hz, c27hz, c28hz, c29hz, c3hz, c31hz, c32hz: out std_logic; 
	c33hz, c34hz, c35hz, c36hz, c38hz, c4hz, c42hz, c44hz, c46hz, c48hz, c5hz: out std_logic;
	c52hz, c54hz, c56hz, c58hz, c6hz: out std_logic
);
end component;
----------------------div_freq_emu----------------------------------------
component div_freq_emu is
port(reset: in std_logic;
	clock: in std_logic;
	c05hz, c07hz, c09hz, c1hz, c11hz, c12hz, c13hz, c14hz, c15hz, c16hz, c17hz, c18hz, c19hz: out std_logic;
	c2hz, c21hz, c22hz, c23hz, c24hz, c25hz, c26hz, c27hz, c28hz, c29hz, c3hz, c31hz, c32hz: out std_logic; 
	c33hz, c34hz, c35hz, c36hz, c38hz, c4hz, c42hz, c44hz, c46hz, c48hz, c5hz: out std_logic;
	c52hz, c54hz, c56hz, c58hz, c6hz: out std_logic
);
end component;
---------------------------logica-----------------------------------------
component logica is
port(
    reg_setuplevel: in std_logic_vector(1 downto 0);
    round: in std_logic_vector(3 downto 0);
	 reg_setupmapa: in std_logic_vector(1 downto 0);
	 points: out std_logic_vector(7 downto 0)
);
end component;
----------------------------comp------------------------------------------
component comp is 
port(
	seq_fpga, seq_usuario: in std_logic_vector(63 downto 0);
	eq: out std_logic
 );
end component;
----------------------------buttonsync------------------------------------
component buttonsync is
	port
	(
		key0, key1, key2, key3, clk: in std_logic;
		btn0, btn1, btn2, btn3: out std_logic
	);
end component;



begin

------------------------------------------------------------
-----------------------e_counter_user-----------------------
------------------------------------------------------------

    e_counter_user <= (nbtn(3) or nbtn(2) or nbtn(1) or nbtn(0)) and e2;

------------------------------------------------------
-----------------------div_freq-----------------------
------------------------------------------------------

    -- DE2
	--impl_div_freq_de2: div_freq_de2 port map(r1,clock, c05hz, c07hz, c09hz, c1hz, c11hz, c12hz, c13hz, c14hz, c15hz, c16hz, c17hz, c18hz, c19hz, c2hz, c21hz, c22hz, c23hz, c24hz, c25hz, c26hz, c27hz, c28hz, c29hz, c3hz, c31hz, c32hz, c33hz, c34hz, c35hz, c36hz, c38hz, c4hz, c42hz, c44hz, c46hz, c48hz, c5hz, c52hz, c54hz, c56hz, c58hz, c6hz);

    -- EMU
	impl_div_freq_emu: div_freq_emu port map(r1,clock, c05hz, c07hz, c09hz, c1hz, c11hz, c12hz, c13hz, c14hz, c15hz, c16hz, c17hz, c18hz, c19hz, c2hz, c21hz, c22hz, c23hz, c24hz, c25hz, c26hz, c27hz, c28hz, c29hz, c3hz, c31hz, c32hz, c33hz, c34hz, c35hz, c36hz, c38hz, c4hz, c42hz, c44hz, c46hz, c48hz, c5hz, c52hz, c54hz, c56hz, c58hz, c6hz);

------------------------------------------------------
-----------------------sel_freq-----------------------
------------------------------------------------------
    impl_sel_freq_0_mux16x1: mux16x1 port map(
        round,
        -- clocks
            c05hz, c07hz, c09hz, c11hz,
            c13hz, c15hz, c17hz, c19hz,
            c21hz, c23hz, c25hz, c27hz,
            c29hz, c31hz, c33hz, c35hz,
        saida0mux16_1
    );

    impl_sel_freq_1_mux16x1: mux16x1 port map(
        round,
        -- clocks
            c1hz, c12hz, c14hz, c16hz,
            c18hz, c2hz, c22hz, c24hz,
            c26hz, c28hz, c3hz, c32hz,
            c34hz, c36hz, c38hz, c4hz,
        saida1mux16_1
    );

    impl_sel_freq_2_mux16x1: mux16x1 port map(
        round,
        -- clocks
            c2hz, c22hz, c24hz, c26hz,
            c28hz, c3hz, c32hz, c34hz,
            c36hz, c38hz, c4hz, c42hz,
            c44hz, c46hz, c48hz, c5hz,
        saida2mux16_1
    );

    impl_sel_freq_3_mux16x1: mux16x1 port map(
        round,
        -- clocks
            c3hz, c32hz, c34hz, c36hz,
            c38hz, c4hz, c42hz, c44hz,
            c46hz, c48hz, c5hz, c52hz,
            c54hz, c56hz, c58hz, c6hz,
        saida3mux16_1
    );

    impl_sel_freq_mux4x1: mux4x1 port map(
        setup(7 downto 6), 
        saida0mux16_1, saida1mux16_1, saida2mux16_1, saida3mux16_1,
        clkhz
    );

--------------------------------------------------
-----------------------led-----------------------
--------------------------------------------------
    leds <= out_fpga(63 downto 60);
    
    notkeys <= (not key(3)) & (not key(2)) & (not key(1)) & (not key(0));

    ledg <= notkeys;

-------------------------------------------------
-----------------------hex-----------------------
-------------------------------------------------

-----------------------hex5-----------------------

    impl_hex5_mux0: mux2x1_7bits port map(
        win_internal,
        "0001110", "1000001",
        output_mux0hex5
    );

    impl_hex5_mux1: mux2x1_7bits port map(
        sel,
        "1000111", output_mux0hex5,
        hex5
    );

-----------------------hex4-----------------------

    g_dec7seghex4 <= "00" & setup(7 downto 6);
    
    impl_hex4_dec7seg: dec7seg port map(
        g_dec7seghex4,
        dec7seghex4
    );

    impl_hex4_mux0: mux2x1_7bits port map(
        win_internal,
        "0001100", "0010010",
        output_mux0hex4
    );

    impl_hex4_mux1: mux2x1_7bits port map(
        sel,
        dec7seghex4, output_mux0hex4,
        hex4
    );

-----------------------hex3-----------------------

    impl_hex3_mux0: mux2x1_7bits port map(
        win_internal,
        "0010000", "0000110",
        output_mux0hex3
    );

    impl_hex3_mux1: mux2x1_7bits port map(
        sel,
        "0000111", output_mux0hex3,
        hex3
    );

-----------------------hex2-----------------------

    impl_hex2_dec7seg: dec7seg port map(
        tempo,
        dec7seghex2
    );

    impl_hex2_mux0: mux2x1_7bits port map(
        win_internal,
        "0001000", "0101111",
        output_mux0hex2
    );

    impl_hex2_mux1: mux2x1_7bits port map(
        sel,
        dec7seghex2, output_mux0hex2,
        hex2
    );

-----------------------hex1-----------------------

    impl_hex1_dec7seg: dec7seg port map(
        points(7 downto 4),
        dec7seghex1
    );

    impl_hex1_mux: mux2x1_7bits port map(
        sel,
        "0101111", dec7seghex1,
        hex1
    );

-----------------------hex0-----------------------

    impl_hex0_dec7seg0: dec7seg port map(
        round,
        dec7seghex00
    );

    impl_hex0_dec7seg1: dec7seg port map(
        points(3 downto 0),
        dec7seghex01
    );

    impl_hex0_mux: mux2x1_7bits port map(
        sel,
        dec7seghex00, dec7seghex01,
        hex0
    );

-------------------------------------------------
-----------------------reg-----------------------
-------------------------------------------------

-----------------------reg_setup-----------------------

    impl_reg_setup: reg_setup port map(
        clock, r1, e1,
        switch(7 downto 0),
        setup
    );

-----------------------reg_fpga-----------------------

    data_reg_fpga <= seq_fpga & out_fpga(63 downto 4);
    
    impl_reg_fpga: reg_fpga port map(
        clock, r2, c2aux,
        data_reg_fpga,
        out_fpga
    );

-----------------------reg_user-----------------------

    data_reg_user <= nbtn & out_user(63 downto 4);

    impl_reg_user: reg_user port map(
        clock, r2, e_counter_user,
        data_reg_user,
        out_user
    );

-----------------------------------------------------
-----------------------counter-----------------------
-----------------------------------------------------

-----------------------counter_time-----------------------

    impl_counter_time: counter_time port map(
        clock,
        r2,
        c1aux,
        tempo,
        end_time
    );

-----------------------counter_round-----------------------

    impl_counter_round: counter_round port map(
        setup(3 downto 0),
        clock,
        r1,
        e4,
        win_internal,
        round
    );

-----------------------counter_fpga-----------------------

    impl_counter_fpga: counter_fpga port map(
        clock,
        r2,
        c2aux,
        round,
        end_fpga,
        seqfpga
    );

-----------------------counter_user-----------------------

    impl_counter_user: counter_user port map(
        clock,
        r2,
        e_counter_user,
        round,
        end_user_internal
    );


-------------------------------------------------
-----------------------seq-----------------------
-------------------------------------------------

-----------------------decseq-----------------------

    impl_decseq00: decseq00 port map(
        seqfpga,
        mux4x1_4bits00
    );

    impl_decseq01: decseq01 port map(
        seqfpga,
        mux4x1_4bits01
    );

    impl_decseq10: decseq10 port map(
        seqfpga,
        mux4x1_4bits10
    );

    impl_decseq11: decseq11 port map(
        seqfpga,
        mux4x1_4bits11
    );

-----------------------seq_mux-----------------------

    impl_seq_mux: mux4x1_4bits port map(
        setup(5 downto 4),
        mux4x1_4bits00, mux4x1_4bits01, mux4x1_4bits10, mux4x1_4bits11,
        seq_fpga
    );

----------------------------------------------------
-----------------------logica-----------------------
----------------------------------------------------

    impl_logica: logica port map(
        setup(7 downto 6),
        round,
        setup(5 downto 4),
        points
    );

--------------------------------------------------
-----------------------comp-----------------------
--------------------------------------------------

    impl_comp: comp port map(
        out_fpga, out_user,
        is_equal
    );

    match <= end_user_internal and is_equal;

--------------------------------------------------------
-----------------------buttonsync-----------------------
--------------------------------------------------------

    impl_buttonsync: buttonsync port map(
        key(0), key(1), key(2), key(3), clock,
        btn0, btn1, btn2, btn3
    );

    nbtn <= (not btn3) & (not btn2) & (not btn1) & (not btn0);


---------------------------------------------------
-----------------------c1aux-----------------------
---------------------------------------------------

    c1aux <= e2 and c1hz;


---------------------------------------------------
-----------------------c2aux-----------------------
---------------------------------------------------

    c2aux <= e3 and clkhz;


-----------------------------------------------------------
-----------------------win, end_user-----------------------
-----------------------------------------------------------

    win <= win_internal;
    end_user <= end_user_internal;
    
end arc;
