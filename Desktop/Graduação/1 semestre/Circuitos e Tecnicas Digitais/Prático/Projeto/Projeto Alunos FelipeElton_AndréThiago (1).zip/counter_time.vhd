library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity counter_time is
port(
    clkt: in std_logic;
    r: in std_logic;
    e: in std_logic;
    tempo: out std_logic_vector(3 downto 0);
    end_time: out std_logic
);
end entity;

architecture arc of counter_time is
    signal sig_tempo: std_logic_vector(3 downto 0);
begin
    process(clkt, r, e)
    begin
        if r = '1' then
            sig_tempo <= "0000";
            end_time <= '0';
        elsif rising_edge(clkt) and e = '1' then
            if sig_tempo = "1010" then
                -- todo
                -- sig_tempo <= "0000"?
                end_time <= '1';
            else
                sig_tempo <= sig_tempo + 1; 
                end_time <= '0';
            end if;
        end if;
    end process;

    tempo <= sig_tempo;
end arc;
