library ieee;
use ieee.std_logic_1164.all;

entity mux4x1_4bits is
port(
    sel: in std_logic_vector(1 downto 0);
    ent0, ent1, ent2, ent3: in std_logic_vector(3 downto 0);
    output: out std_logic_vector(3 downto 0)
);
end entity;

architecture arc of mux4x1_4bits is

begin
    with sel select
        output <= 
            ent0 when "00",
            ent1 when "01",
            ent2 when "10",
            ent3 when others;
end arc;

