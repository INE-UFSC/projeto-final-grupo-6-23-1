library ieee;
use ieee.std_logic_1164.all;

entity logica is
port(
    reg_setuplevel: in std_logic_vector(1 downto 0);
    round: in std_logic_vector(3 downto 0);
	reg_setupmapa: in std_logic_vector(1 downto 0);
	points: out std_logic_vector(7 downto 0)
);
end entity;

architecture arc of logica is
begin
    -- i = reg_setupmapa
    -- round = round
    -- j = reg_setuplevel

    -- j1 j0 00 00 00 00 00 00
    -- 00 00 r3 r2 r1 r0 00 00
    -- 00 00 00 00 00 00 i1 i0
    points <= reg_setuplevel & round & reg_setupmapa; 
end arc;
