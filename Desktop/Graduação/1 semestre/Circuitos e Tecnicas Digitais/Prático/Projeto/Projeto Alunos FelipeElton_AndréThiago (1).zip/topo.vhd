library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity topo is
port(
	-- entradas
	-- DE2
	--clock_50: in std_logic;
	-- EMU
	clk_500hz: in std_logic;
	key: in std_logic_vector(3 downto 0);
	sw: in std_logic_vector(9 downto 0);
	-- saídas
	-- EMU
	ledr: out std_logic_vector(17 downto 0);
	-- DE2
	--ledr: out std_logic_vector(4 downto 0);
	-- DE2
	--ledg: out std_logic_vector(3 downto 0);
	hex0: out std_logic_vector(6 downto 0);
	hex1: out std_logic_vector(6 downto 0);
	hex2: out std_logic_vector(6 downto 0);
	hex3: out std_logic_vector(6 downto 0);
	hex4: out std_logic_vector(6 downto 0);
	hex5: out std_logic_vector(6 downto 0);
	hex6: out std_logic_vector(6 downto 0);
	hex7: out std_logic_vector(6 downto 0)
);
end entity;

architecture arc of topo is

	
---------------------------components------------------------------------

---------------------------datapath--------------------------------------
component datapath is
port(
	clock: in std_logic;
	key: in std_logic_vector(3 downto 0);
	switch: in std_logic_vector(7 downto 0);
	r1, r2, e1, e2, e3, e4: in std_logic;
	sel: in std_logic;
	hex0, hex1, hex2, hex3, hex4, hex5: out std_logic_vector(6 downto 0);
	leds: out std_logic_vector(3 downto 0);
	ledg: out std_logic_vector(3 downto 0);
	end_fpga, end_user, end_time, win, match: out std_logic
);
end component;
---------------------------controle--------------------------------------
component controle is
port(
	clock: in std_logic;
	enter: in std_logic;
	reset: in std_logic;
	end_fpga, end_user, end_time, win, match: in std_logic;
	r1, r2, e1, e2, e3, e4: out std_logic;
	sel: out std_logic
);
end component;
-----------------------------signals-------------------------------------
--clock---------------------------------------------
	signal clock: std_logic;
	
--pmcontrole----------------------------------------
	signal r1: std_logic;
	signal r2: std_logic;
	signal e1: std_logic;
	signal e2: std_logic;
	signal e3: std_logic;
	signal e4: std_logic;
	signal end_fpga: std_logic;
	signal end_user: std_logic;
	signal end_time: std_logic;
	signal win: std_logic;
	signal match: std_logic;
	signal sel: std_logic;



begin
    -- EMU
	clock <= clk_500hz; --emulador
	-- DE2
	--clock <= clock_50;
	ledr(4) <= win;
	
	hex6 <= "1111111"; --desliga o hex 6
	hex7 <= "1111111"; --desliga o hex 7
	
	
-- a fazer o resto pel@ alun@

    impl_datapath: datapath port map(
        clock,
    	key(3 downto 0),
    	sw(9 downto 2),
    	r1, r2, e1, e2, e3, e4,
    	sel,
    	hex0, hex1, hex2, hex3, hex4, hex5,
    	ledr(3 downto 0),
    	-- EMU
    	ledr(17 downto 14),
    	-- DE2
    	--ledg(3 downto 0),
    	end_fpga, end_user, end_time, win, match
    );
    
    impl_controle: controle port map(
        clock,
    	sw(0),
    	sw(1),
    	end_fpga, end_user, end_time, win, match,
    	r1, r2, e1, e2, e3, e4,
    	sel
    );
end architecture;
