-- transforma o clock de 500hz (clk_500hz) vindo do emulador em sinais de 0.5hz - 6.0hz.

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity div_freq_emu is
port(reset: in std_logic;
	clock: in std_logic;
	c05hz, c07hz, c09hz, c1hz, c11hz, c12hz, c13hz, c14hz, c15hz, c16hz, c17hz, c18hz, c19hz: out std_logic;
	c2hz, c21hz, c22hz, c23hz, c24hz, c25hz, c26hz, c27hz, c28hz, c29hz, c3hz, c31hz, c32hz: out std_logic; 
	c33hz, c34hz, c35hz, c36hz, c38hz, c4hz, c42hz, c44hz, c46hz, c48hz, c5hz: out std_logic;
	c52hz, c54hz, c56hz, c58hz, c6hz: out std_logic
);
end div_freq_emu;

architecture arc of div_freq_emu is
	signal c05, c07 , c09, c1, c11, c12, c13, c14, c15, c16, c17, c18, c19, c2, c21, c22, c23, c24, c25, c26, c27, c28, c29, c3, c31, c32, c33, c34, c35, c36, c38, c4, c42, c44, c46, c48, c5, c52, c54, c56, c58, c6: std_logic_vector(11 downto 0):= x"000"; -- precisamos de 12 bits para representar ateh o valor 1000 
begin
	process(reset,clock, c05, c07 , c09, c1, c11, c12, c13, c14, c15, c16, c17, c18, c19, c2, c21, c22, c23, c24, c25, c26, c27, c28, c29, c3, c31, c32, c33, c34, c35, c36, c38, c4, c42, c44, c46, c48, c5, c52, c54, c56, c58, c6)
	begin
		-- reset
		if reset = '1' then
			c05 <= x"000"; -- notacao para hexadecimal: x"valor em hexa"
			c07 <= x"000";
			c09 <= x"000";
			c1 <= x"000";
			c11 <= x"000";
			c12 <= x"000";
			c13 <= x"000";
			c14 <= x"000";
			c15 <= x"000";
			c16 <= x"000";
			c17 <= x"000";
			c18 <= x"000";
			c19 <= x"000";
			c2 <= x"000";
			c21 <= x"000";
			c22 <= x"000";
			c23 <= x"000";
			c24 <= x"000";
			c25 <= x"000";
			c26 <= x"000";
			c27 <= x"000";
			c28 <= x"000";
			c29 <= x"000";
			c3 <= x"000";
			c31 <= x"000";
			c32 <= x"000";
			c33 <= x"000";
			c34 <= x"000";
			c35 <= x"000";
			c36 <= x"000";
			c38 <= x"000";
			c4 <= x"000";
			c42 <= x"000";
			c44 <= x"000";
			c46 <= x"000";
			c48 <= x"000";
			c5 <= x"000";
			c52 <= x"000";
			c54 <= x"000";
			c56 <= x"000";
			c58 <= x"000";
			c6 <= x"000"; 			

		elsif (clock'event and clock = '1') then
		-- incrementa todos os contadores
			c05 <= c05 + 1;
			c07 <= c07 + 1;
			c09 <= c09 + 1;
			c1 <= c1 + 1;
			c11 <= c11 + 1;
			c12 <= c12 + 1;
			c13 <= c13 + 1;
			c14 <= c14 + 1;
			c15 <= c15 + 1;
			c16 <= c16 + 1;
			c17 <= c17 + 1;
			c18 <= c18 + 1;
			c19 <= c19 + 1;
			c2 <= c2 + 1;
			c21 <= c21 + 1;
			c22 <= c22 + 1;
			c23 <= c23 + 1;
			c24 <= c24 + 1;
			c25 <= c25 + 1;
			c26 <= c26 + 1;
			c27 <= c27 + 1;
			c28 <= c28 + 1;
			c29 <= c29 + 1;
			c3 <= c3 + 1;
			c31 <= c31 + 1;
			c32 <= c32 + 1;
			c33 <= c33 + 1;
			c34 <= c34 + 1;
			c35 <= c35 + 1;
			c36 <= c36 + 1;
			c38 <= c38 + 1;
			c4 <= c4 + 1;
			c42 <= c42 + 1;
			c44 <= c44 + 1;
			c46 <= c46 + 1;
			c48 <= c48 + 1;
			c5 <= c5 + 1;
			c52 <= c52 + 1;
			c54 <= c54 + 1;
			c56 <= c56 + 1;
			c58 <= c58 + 1;
			c6 <= c6 + 1;
		
		-- quando o signal do contador de 0.5hz (c05) chega a 999 ({[freq do clock]/[freq desejada] - 1}), zera o contador e ativa a saida c05hz

			if c05 = x"3e7" then --3e7 eh 999 em hexadecimal
				c05hz <= '1'; -- da um pulso para o clock de 0.5hz (isto ocorrera a cada 2s)
				c05 <= x"000"; -- ao completar as 999 voltas, zera o signal do contador
			else 
				c05hz <= '0'; --	enquanto nao chegar a 999, mantem c05hz em 0
			end if;

		-- 0.7hz
			if c07 = x"2c9" then
				c07hz <= '1';
				c07 <= x"000";
			else 
				c07hz <= '0';
			end if;

		-- 0.9hz
			if c09 = x"22b" then
				c09hz <= '1';
				c09 <= x"000";
			else 
				c09hz <= '0';
			end if;
		
		-- 1hz
			if c1 = x"1f3" then
				c1hz <= '1';
				c1 <= x"000";
			else
				c1hz <= '0';
			end if;
		
		-- 1.1hz
			if c11 = x"1c6" then
				c11hz <= '1';
				c11 <= x"000";
			else
				c11hz <= '0';
			end if;
		
		-- 1.2hz
			if c12 = x"1a0" then
				c12hz <= '1';
				c12 <= x"000";
			else
				c12hz <= '0';
			end if;
		
		-- 1.3hz
			if c13 = x"180" then
				c13hz <= '1';
				c13 <= x"000";
			else
				c13hz <= '0';
			end if;
		
		-- 1.4hz
			if c14 = x"164" then
				c14hz <= '1';
				c14 <= x"000";
			else
				c14hz <= '0';
			end if;
		
		-- 1.5hz
			if c15 = x"14c" then
				c15hz <= '1';
				c15 <= x"000";
			else
				c15hz <= '0';
			end if;
		
		-- 1.6hz
			if c16 = x"138" then
				c16hz <= '1';
				c16 <= x"000";
			else
				c16hz <= '0';
			end if;
		
		-- 1.7hz
			if c17 = x"125" then
				c17hz <= '1';
				c17 <= x"000";
			else
				c17hz <= '0';
			end if;
		
		-- 1.8hz
			if c18 = x"115" then
				c18hz <= '1';
				c18 <= x"000";
			else
				c18hz <= '0';
			end if;
		
		-- 1.9hz
			if c19 = x"106" then
				c19hz <= '1';
				c19 <= x"000";
			else
				c19hz <= '0';
			end if;
			
		-- 2hz
		
			if c2 = x"0f9" then
				c2hz <= '1';
				c2 <= x"000";
			else 
				c2hz <= '0';
			end if;
			
		-- 2.1hz
		
			if c21 = x"0ed" then
				c21hz <= '1';
				c21 <= x"000";
			else 
				c21hz <= '0';
			end if;
			
		-- 2.2hz
		
			if c22 = x"0e2" then
				c22hz <= '1';
				c22 <= x"000";
			else 
				c22hz <= '0';
			end if;
			
		-- 2.3hz
		
			if c23 = x"0d8" then
				c23hz <= '1';
				c23 <= x"000";
			else 
				c23hz <= '0';
			end if;
			
		-- 2.4hz
		
			if c24 = x"0cf" then
				c24hz <= '1';
				c24 <= x"000";
			else 
				c24hz <= '0';
			end if;
			
		-- 2.5hz
		
			if c25 = x"0c7" then
				c25hz <= '1';
				c25 <= x"000";
			else 
				c25hz <= '0';
			end if;
			
		-- 2.6hz
		
			if c26 = x"0bf" then
				c26hz <= '1';
				c26 <= x"000";
			else 
				c26hz <= '0';
			end if;
			
		-- 2.7hz
		
			if c27 = x"0b8" then
				c27hz <= '1';
				c27 <= x"000";
			else 
				c27hz <= '0';
			end if;
			
		-- 2.8hz
		
			if c28 = x"0b2" then
				c28hz <= '1';
				c28 <= x"000";
			else 
				c28hz <= '0';
			end if;
			
		-- 2.9hz
		
			if c29 = x"0ab" then
				c29hz <= '1';
				c29 <= x"000";
			else 
				c29hz <= '0';
			end if;

		-- 3hz
			if c3 = x"0a6" then
				c3hz <= '1';
				c3 <= x"000";
			else
				c3hz <= '0';
			end if;

		-- 3.1hz
			if c31 = x"0a0" then
				c31hz <= '1';
				c31 <= x"000";
			else
				c31hz <= '0';
			end if;

		-- 3.2hz
			if c32 = x"09b" then
				c32hz <= '1';
				c32 <= x"000";
			else
				c32hz <= '0';
			end if;

		-- 3.3hz
			if c33 = x"097" then
				c33hz <= '1';
				c33 <= x"000";
			else
				c33hz <= '0';
			end if;

		-- 3.4hz
			if c34 = x"092" then
				c34hz <= '1';
				c34 <= x"000";
			else
				c34hz <= '0';
			end if;

		-- 3.5hz
			if c35 = x"08e" then
				c35hz <= '1';
				c35 <= x"000";
			else
				c35hz <= '0';
			end if;

		-- 3.6hz
			if c36 = x"08a" then
				c36hz <= '1';
				c36 <= x"000";
			else
				c36hz <= '0';
			end if;

		-- 3.8hz
			if c38 = x"083" then
				c38hz <= '1';
				c38 <= x"000";
			else
				c38hz <= '0';
			end if;

		-- 4.0hz
			if c4 = x"07c" then
				c4hz <= '1';
				c4 <= x"000";
			else
				c4hz <= '0';
			end if;

		-- 4.2hz
			if c42 = x"076" then
				c42hz <= '1';
				c42 <= x"000";
			else
				c42hz <= '0';
			end if;

		-- 4.4hz
			if c44 = x"071" then
				c44hz <= '1';
				c44 <= x"000";
			else
				c44hz <= '0';
			end if;

		-- 4.6hz
			if c46 = x"06c" then
				c46hz <= '1';
				c46 <= x"000";
			else
				c46hz <= '0';
			end if;

		-- 4.8hz
			if c48 = x"067" then
				c48hz <= '1';
				c48 <= x"000";
			else
				c48hz <= '0';
			end if;

		-- 5.0hz
			if c5 = x"063" then
				c5hz <= '1';
				c5 <= x"000";
			else
				c5hz <= '0';
			end if;

		-- 5.2hz
			if c52 = x"05f" then
				c52hz <= '1';
				c52 <= x"000";
			else
				c52hz <= '0';
			end if;

		-- 5.4hz
			if c54 = x"05c" then
				c54hz <= '1';
				c54 <= x"000";
			else
				c54hz <= '0';
			end if;

		-- 5.6hz
			if c56 = x"058" then
				c56hz <= '1';
				c56 <= x"000";
			else
				c56hz <= '0';
			end if;

		-- 5.8hz
			if c58 = x"055" then
				c58hz <= '1';
				c58 <= x"000";
			else
				c58hz <= '0';
			end if;

		-- 6.0hz
			if c6 = x"052" then
				c6hz <= '1';
				c6 <= x"000";
			else
				c6hz <= '0';
			end if;
			
		end if;
	end process;
end arc;
