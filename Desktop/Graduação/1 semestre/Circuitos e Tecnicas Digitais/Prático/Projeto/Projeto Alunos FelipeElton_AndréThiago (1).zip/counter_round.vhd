library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity counter_round is
port(
	data: in std_logic_vector(3 downto 0);
	clk: in std_logic;
    r: in std_logic;
    e: in std_logic;
    tc : out std_logic;	
    round: out std_logic_vector(3 downto 0)
);
end entity;

architecture arc of counter_round is
    signal sig_round: std_logic_vector(3 downto 0);
begin
    process(data, clk, r, e)
    begin
        if r = '1' then
            sig_round <= "0000";
            tc <= '0';
        elsif rising_edge(clk) and e = '1' then
            if sig_round = data then
                -- todo
                --sig_round <= "0000"?
                tc <= '1';
            else
                sig_round <= sig_round + 1; 
                tc <= '0';
            end if;
        end if;
    end process;

    round <= sig_round;
end arc;

