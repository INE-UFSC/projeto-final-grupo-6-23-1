library ieee;
use ieee.std_logic_1164.all;

entity mux16x1 is
port(sel: in std_logic_vector(3 downto 0);
    f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16: in std_logic;
    clkhz: out std_logic
);
end entity;

architecture arc of mux16x1 is
begin
    with sel select
        clkhz <=
            f1 when "0000",
            f2 when "0001",
            f3 when "0010",
            f4 when "0011",
            f5 when "0100",
            f6 when "0101",
            f7 when "0110",
            f8 when "0111",
            f9 when "1000",
            f10 when "1001",
            f11 when "1010",
            f12 when "1011",
            f13 when "1100",
            f14 when "1101",
            f15 when "1110",
            f16 when others;
end arc;
