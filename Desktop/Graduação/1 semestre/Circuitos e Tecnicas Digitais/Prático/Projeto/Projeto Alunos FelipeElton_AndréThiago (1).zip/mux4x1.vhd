library ieee;
use ieee.std_logic_1164.all;

entity mux4x1 is
port(level: in std_logic_vector(1 downto 0);
    cl1, cl2, cl3, cl4: in std_logic;
    clkhz: out std_logic
);
end entity;

architecture arc of mux4x1 is
begin
    with level select
        clkhz <=
            cl1 when "00",
            cl2 when "01",
            cl3 when "10",
            cl4 when others;
end arc;
